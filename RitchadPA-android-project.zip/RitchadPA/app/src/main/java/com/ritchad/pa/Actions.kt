package com.ritchad.pa

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings

private var torchOn = false

/** Phone actions triggered by commands. Returns a reply, or null if the text isn't an action. */
fun runAction(c: Context, t: String): String? {
    val x = t.lowercase().trim()
    fun go(i: Intent) {   // slight delay so Ritchad can finish speaking first
        Handler(Looper.getMainLooper()).postDelayed({
            try { c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) {} }, 1400)
    }
    val web = { u: String -> go(Intent(Intent.ACTION_VIEW, Uri.parse(u))) }
    when {
        x.startsWith("open ") || x.startsWith("launch ") || x.startsWith("start ") -> {
            val name = x.substringAfter(" ").removePrefix("the ").removeSuffix(" app").trim()
            val special = mapOf("settings" to Settings.ACTION_SETTINGS, "wifi" to Settings.ACTION_WIFI_SETTINGS,
                "wi-fi" to Settings.ACTION_WIFI_SETTINGS, "bluetooth" to Settings.ACTION_BLUETOOTH_SETTINGS,
                "camera" to MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
            special[name]?.let { go(Intent(it)); return "Opening $name, $MASTER." }
            val pm = c.packageManager
            val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            val m = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == name }
                ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(name) }
            val i = m?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
            if (i != null) { go(i); return "Opening ${m.loadLabel(pm)}, $MASTER." }
            return "I couldn't find an app called $name, $MASTER."
        }
        x.startsWith("search ") || x.startsWith("google ") -> {
            val q = x.substringAfter(" "); web("https://www.google.com/search?q=" + Uri.encode(q)); return "Searching for $q, $MASTER."
        }
        x.startsWith("play ") -> { val q = x.removePrefix("play "); web("https://www.youtube.com/results?search_query=" + Uri.encode(q)); return "Playing $q on YouTube, $MASTER." }
        x.startsWith("call ") || x.startsWith("dial ") -> {
            val d = x.filter { it.isDigit() || it == '+' }
            if (d.isEmpty()) return "Please say the number to dial, $MASTER."
            go(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$d"))); return "Dialing $d, $MASTER."
        }
        x.startsWith("navigate to ") || x.startsWith("directions to ") -> {
            val q = x.substringAfter(" to "); go(Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(q)))); return "Navigating to $q, $MASTER."
        }
        x.contains("timer") && x.any { it.isDigit() } -> {
            val n = x.filter { it.isDigit() }.toInt(); val secs = if (x.contains("second")) n else n * 60
            go(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, secs).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            return "Timer set, $MASTER."
        }
        x.contains("flashlight") || x.contains("torch") -> {
            val on = !x.contains(" off")
            return try {
                val cm = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                val id = cm.cameraIdList.first { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
                cm.setTorchMode(id, on); torchOn = on; if (on) "Flashlight on, $MASTER." else "Flashlight off, $MASTER."
            } catch (e: Exception) { "I couldn't reach the flashlight, $MASTER." }
        }
    }
    return null
}
