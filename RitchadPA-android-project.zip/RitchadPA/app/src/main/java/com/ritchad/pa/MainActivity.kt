package com.ritchad.pa

import android.Manifest
import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import android.speech.tts.UtteranceProgressListener
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.platform.LocalLifecycleOwner
import android.content.*
import android.content.pm.PackageManager
import android.graphics.*
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.provider.Settings
import android.speech.*
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.*
import androidx.compose.ui.graphics.ColorMatrix as CMx
import java.io.File
import java.util.Locale

val Navy = Color(0xFF050A18); val Cyan = Color(0xFF00E5FF); val Blue = Color(0xFF2979FF)
val Dim = Color(0xFF9FB4D0)

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) { super.onCreate(b); setContent { Root() } }
}

@Composable fun Root() {
    val ctx = LocalContext.current; val s = remember { Store(ctx) }
    var unlocked by remember { mutableStateOf(false) }
    MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Navy, surface = Navy)) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0A1530), Navy, Color.Black)))) {
            Stars()
            Box(Modifier.fillMaxSize().systemBarsPadding()) {
            if (!unlocked) Lock(s) { unlocked = true } else App(s) { unlocked = false }
            }
        }
    }
}

// ---------- UI kit ----------
@Composable fun Stars() = Canvas(Modifier.fillMaxSize()) {
    val rnd = java.util.Random(7)
    repeat(80) { drawCircle(Cyan.copy(alpha = 0.08f + rnd.nextFloat() * 0.4f), rnd.nextFloat() * 2.2f + 0.6f,
        Offset(rnd.nextFloat() * size.width, rnd.nextFloat() * size.height)) }
    val c1 = Offset(size.width * .85f, size.height * .08f); val c2 = Offset(size.width * .1f, size.height * .9f)
    drawCircle(Brush.radialGradient(listOf(Blue.copy(.35f), Color.Transparent), c1, size.width * .7f), size.width * .7f, c1)
    drawCircle(Brush.radialGradient(listOf(Cyan.copy(.18f), Color.Transparent), c2, size.width * .6f), size.width * .6f, c2)
}
@Composable fun Title(t: String) = Text(t, color = Cyan, fontSize = 22.sp, fontWeight = FontWeight.Bold, letterSpacing = 5.sp,
    style = androidx.compose.ui.text.TextStyle(shadow = androidx.compose.ui.graphics.Shadow(Cyan, blurRadius = 28f)))
@Composable fun Glass(m: Modifier = Modifier, onClick: (() -> Unit)? = null, c: @Composable ColumnScope.() -> Unit) {
    val sh = RoundedCornerShape(22.dp)
    var mod = m.clip(sh).background(Brush.linearGradient(listOf(Color(0x22FFFFFF), Color(0x0A00E5FF))))
        .border(1.dp, Brush.linearGradient(listOf(Cyan.copy(.6f), Blue.copy(.15f))), sh)
    if (onClick != null) mod = mod.clickable { onClick() }
    Column(mod.padding(16.dp), content = c)
}
@Composable fun Txt(t: String, big: Boolean = false, col: Color = Color.White) =
    Text(t, color = col, fontSize = if (big) 20.sp else 15.sp, fontWeight = if (big) FontWeight.SemiBold else FontWeight.Normal)
@Composable fun Neon(t: String, m: Modifier = Modifier, on: () -> Unit) =
    Button(on, m, colors = ButtonDefaults.buttonColors(containerColor = Cyan.copy(.18f), contentColor = Cyan),
        border = BorderStroke(1.dp, Cyan.copy(.6f))) { Text(t) }
@Composable fun Field(v: String, ch: (String) -> Unit, hint: String, m: Modifier = Modifier, pw: Boolean = false) =
    OutlinedTextField(v, ch, m, placeholder = { Text(hint, color = Dim) }, singleLine = true,
        visualTransformation = if (pw) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Cyan, unfocusedBorderColor = Cyan.copy(.3f),
            focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = Cyan))

@Composable fun Orb(active: Boolean, size: Dp = 200.dp) {
    val t = rememberInfiniteTransition(label = "o")
    val sc by t.animateFloat(1f, if (active) 1.18f else 1.06f,
        infiniteRepeatable(tween(if (active) 600 else 2200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "s")
    Box(Modifier.size(size * 1.5f), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(size).scale(sc)) {
            val r = this.size.minDimension / 2
            drawCircle(Brush.radialGradient(listOf(Cyan.copy(.55f), Blue.copy(.2f), Color.Transparent), radius = r * 1.5f), r * 1.5f)
            drawCircle(Brush.radialGradient(listOf(Color(0xFFB2F5FF), Cyan, Blue, Color(0xFF0A1A4A)),
                center = Offset(this.size.width * .4f, this.size.height * .35f), radius = r * 1.1f), r * .75f)
        }
        Text("RITCHAD", color = Color.White, fontWeight = FontWeight.Bold, letterSpacing = 3.sp, fontSize = 15.sp)
    }
}

@Composable fun Screen(title: String, back: () -> Unit, c: @Composable ColumnScope.() -> Unit) =
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(back) { Text("← Back", color = Cyan) }; Spacer(Modifier.width(8.dp)); Txt(title, true)
        }
        Spacer(Modifier.height(8.dp)); c()
    }

// ---------- Lock: only the owner (PIN holder) gets in ----------
@Composable fun Lock(s: Store, ok: () -> Unit) {
    var pin by remember { mutableStateOf("") }; var pin2 by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }; val first = s.pinHash == null
    Column(Modifier.fillMaxSize().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Orb(false, 150.dp)
        Txt(if (first) "Create your master PIN, $MASTER" else "Welcome back, $MASTER", true)
        Spacer(Modifier.height(16.dp))
        Field(pin, { pin = it.filter(Char::isDigit).take(8) }, "PIN", pw = true)
        if (first) { Spacer(Modifier.height(8.dp)); Field(pin2, { pin2 = it.filter(Char::isDigit).take(8) }, "Confirm PIN", pw = true) }
        Spacer(Modifier.height(12.dp))
        Neon(if (first) "Set PIN" else "Unlock") {
            if (first) { if (pin.length >= 4 && pin == pin2) { s.pinHash = Store.hash(pin); ok() } else err = "PINs must match (4+ digits)" }
            else if (Store.hash(pin) == s.pinHash) ok() else { err = "Access denied. Only $MASTER may command me."; pin = "" }
        }
        if (err.isNotEmpty()) Txt(err, col = Color(0xFFFF6B6B))
    }
}

// ---------- Navigation ----------
@Composable fun App(s: Store, lock: () -> Unit) {
    var scr by remember { mutableStateOf("home") }; val back = { scr = "home" }
    when (scr) {
        "voice" -> VoiceScreen(s, back); "chat" -> ChatScreen(s, back); "tasks" -> TasksScreen(s, back)
        "files" -> FilesScreen(back); "image" -> ImageScreen(back); "memory" -> MemoryScreen(s, back)
        "settings" -> SettingsScreen(s, back, lock)
        else -> Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Title("RITCHAD PA"); Orb(false, 170.dp); Txt("At your service, $MASTER", true); Spacer(Modifier.height(16.dp))
            val tiles = listOf("🎙️ Voice" to "voice", "💬 Chat" to "chat", "✅ Tasks" to "tasks", "📁 Files" to "files",
                "🖼️ Image Editor" to "image", "🧠 Memory" to "memory", "⚙️ Settings" to "settings")
            LazyVerticalGrid(androidx.compose.foundation.lazy.grid.GridCells.Fixed(2), verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(tiles.size) { i -> Glass(Modifier.fillMaxWidth().height(92.dp), { scr = tiles[i].second }) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Txt(tiles[i].first, true) } } }
            }
        }
    }
}

// ---------- Voice (hands-free) ----------
@Composable fun VoiceScreen(s: Store, back: () -> Unit) {
    val ctx = LocalContext.current; val h = remember { Handler(Looper.getMainLooper()) }
    var status by remember { mutableStateOf("Hands-free ON. Speak any time, $MASTER") }
    var listening by remember { mutableStateOf(false) }; var reply by remember { mutableStateOf("") }
    var hands by remember { mutableStateOf(true) }
    val resumed = remember { booleanArrayOf(true) }
    val go = remember { arrayOfNulls<() -> Unit>(1) }; val done = remember { arrayOfNulls<() -> Unit>(1) }
    val tts = remember { var t: TextToSpeech? = null
        t = TextToSpeech(ctx) { t?.language = Locale.getDefault()
            t?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onDone(id: String?) { h.post { done[0]?.invoke() } }
                @Deprecated("x") override fun onError(id: String?) { h.post { done[0]?.invoke() } } }) }
        t!! }
    val rec = remember { SpeechRecognizer.createSpeechRecognizer(ctx) }
    fun again(d: Long) { if (hands && resumed[0]) h.postDelayed({ if (hands && resumed[0]) go[0]?.invoke() }, d) }
    done[0] = { again(300) }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it) again(100) else { hands = false; status = "Microphone permission denied" } }
    go[0] = {
        if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) perm.launch(Manifest.permission.RECORD_AUDIO)
        else {
            rec.setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle?) {
                    listening = false
                    val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (t == null) { again(300); return }
                    status = "You: $t"; val x = t.lowercase()
                    if (x.contains("stop listening") || x == "stop") { hands = false; status = "Hands-free OFF. Tap the orb."; return }
                    val a = brain(t, s, ctx); reply = a
                    if (s.speak) tts.speak(a, TextToSpeech.QUEUE_FLUSH, null, "r") else again(400)
                }
                override fun onError(e: Int) {
                    listening = false
                    when (e) {
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> again(300)
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> { rec.cancel(); again(800) }
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> { hands = false; status = "Microphone permission needed" }
                        else -> { status = "Voice hiccup, retrying…"; again(1500) }
                    }
                }
                override fun onReadyForSpeech(p: Bundle?) {}; override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}; override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}; override fun onPartialResults(b: Bundle?) {}
                override fun onEvent(t: Int, b: Bundle?) {}
            })
            listening = true; if (reply.isEmpty()) status = "Listening…"
            rec.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM))
        }
    }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val o = LifecycleEventObserver { _, e -> when (e) {
            Lifecycle.Event.ON_PAUSE -> { resumed[0] = false; rec.cancel(); listening = false }
            Lifecycle.Event.ON_RESUME -> { resumed[0] = true; again(700) }
            else -> {} } }
        owner.lifecycle.addObserver(o); onDispose { owner.lifecycle.removeObserver(o) } }
    DisposableEffect(Unit) {
        val w = (ctx as Activity).window; w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose { resumed[0] = false; h.removeCallbacksAndMessages(null); w.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            tts.shutdown(); rec.destroy() } }
    Screen("Voice", { hands = false; back() }) {
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Box(Modifier.clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) {
                if (hands) { hands = false; rec.cancel(); tts.stop(); listening = false; status = "Hands-free OFF. Tap the orb." }
                else { hands = true; status = "Hands-free ON"; again(0) } }) { Orb(listening, 220.dp) }
            Spacer(Modifier.height(24.dp)); Txt(status, col = Cyan)
            Spacer(Modifier.height(6.dp)); Text("Say \"stop listening\" to pause. Tap the orb to toggle.", color = Dim, fontSize = 12.sp)
            if (reply.isNotEmpty()) { Spacer(Modifier.height(16.dp)); Glass(Modifier.fillMaxWidth()) { Txt(reply) } }
        }
    }
}

// ---------- Chat ----------
@Composable fun ChatScreen(s: Store, back: () -> Unit) {
    val ctx = LocalContext.current
    val msgs = remember { mutableStateListOf<String>().apply { addAll(s.list("chat")) } }
    var input by remember { mutableStateOf("") }; val st = rememberLazyListState()
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) st.animateScrollToItem(msgs.lastIndex) }
    Screen("Chat", back) {
        LazyColumn(Modifier.weight(1f), state = st, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(msgs.size) { i -> val me = msgs[i].startsWith("me|")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (me) Arrangement.End else Arrangement.Start) {
                    Glass(Modifier.widthIn(max = 290.dp)) { Txt(msgs[i].substring(3), col = if (me) Cyan else Color.White) } } }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Field(input, { input = it }, "Command me, $MASTER…", Modifier.weight(1f)); Spacer(Modifier.width(8.dp))
            Neon("Send") { if (input.isNotBlank()) { msgs += "me|$input"; msgs += "ai|" + brain(input, s, ctx); input = ""
                s.save("chat", msgs.takeLast(60)) } }
        }
    }
}

// ---------- Tasks ----------
@Composable fun TasksScreen(s: Store, back: () -> Unit) {
    val l = remember { mutableStateListOf<String>().apply { addAll(s.list("tasks")) } }; var n by remember { mutableStateOf("") }
    Screen("Tasks", back) {
        Row { Field(n, { n = it }, "New task", Modifier.weight(1f)); Spacer(Modifier.width(8.dp))
            Neon("Add") { if (n.isNotBlank()) { l += "0|$n"; n = ""; s.save("tasks", l) } } }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 12.dp)) {
            items(l.size) { i -> val d = l[i].startsWith("1|")
                Glass(Modifier.fillMaxWidth()) { Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(d, { l[i] = (if (it) "1|" else "0|") + l[i].substring(2); s.save("tasks", l) })
                    Box(Modifier.weight(1f)) { Txt(l[i].substring(2), col = if (d) Dim else Color.White) }
                    TextButton({ l.removeAt(i); s.save("tasks", l) }) { Text("✕", color = Color(0xFFFF6B6B)) } } } }
        }
    }
}

// ---------- Memory ----------
@Composable fun MemoryScreen(s: Store, back: () -> Unit) {
    val l = remember { mutableStateListOf<String>().apply { addAll(s.list("mem")) } }; var n by remember { mutableStateOf("") }
    Screen("Memory", back) {
        Row { Field(n, { n = it }, "Teach me something", Modifier.weight(1f)); Spacer(Modifier.width(8.dp))
            Neon("Save") { if (n.isNotBlank()) { l += n; n = ""; s.save("mem", l) } } }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 12.dp)) {
            items(l.size) { i -> Glass(Modifier.fillMaxWidth()) { Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f)) { Txt("🧠 " + l[i]) }
                TextButton({ l.removeAt(i); s.save("mem", l) }) { Text("✕", color = Color(0xFFFF6B6B)) } } } }
        }
    }
}

// ---------- Files ----------
@Composable fun FilesScreen(back: () -> Unit) {
    val ctx = LocalContext.current; val dir = remember { File(ctx.filesDir, "uploads").apply { mkdirs() } }
    var files by remember { mutableStateOf(dir.listFiles()?.toList() ?: emptyList()) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { u ->
            val name = ctx.contentResolver.query(u, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null } ?: "file_${System.currentTimeMillis()}"
            ctx.contentResolver.openInputStream(u)?.use { i -> File(dir, name).outputStream().use { o -> i.copyTo(o) } }
        }
        files = dir.listFiles()?.toList() ?: emptyList()
    }
    Screen("Files", back) {
        Neon("＋ Upload files") { pick.launch(arrayOf("*/*")) }
        if (files.isEmpty()) Txt("\nNo files yet, $MASTER.", col = Dim)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 12.dp)) {
            items(files.size) { i -> val f = files[i]
                Glass(Modifier.fillMaxWidth()) { Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Txt("📄 " + f.name); Text("${f.length() / 1024} KB", color = Dim, fontSize = 12.sp) }
                    TextButton({ f.delete(); files = dir.listFiles()?.toList() ?: emptyList() }) { Text("Delete", color = Color(0xFFFF6B6B)) } } } }
        }
    }
}

// ---------- Image editor ----------
fun matrix(b: Float, c: Float, sat: Float): ColorMatrix {
    val m = ColorMatrix().apply { setSaturation(sat) }
    m.postConcat(ColorMatrix(floatArrayOf(c, 0f, 0f, 0f, b, 0f, c, 0f, 0f, b, 0f, 0f, c, 0f, b, 0f, 0f, 0f, 1f, 0f))); return m
}
@Composable fun ImageScreen(back: () -> Unit) {
    val ctx = LocalContext.current
    var bmp by remember { mutableStateOf<Bitmap?>(null) }
    var br by remember { mutableStateOf(0f) }; var ct by remember { mutableStateOf(1f) }
    var sa by remember { mutableStateOf(1f) }; var rot by remember { mutableStateOf(0f) }; var msg by remember { mutableStateOf("") }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u: Uri? ->
        if (u != null) ctx.contentResolver.openInputStream(u)?.use {
            bmp = BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = 2 }); br = 0f; ct = 1f; sa = 1f; rot = 0f } }
    Screen("Image Editor", back) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Neon("Open") { pick.launch("image/*") }; Neon("⟳ Rotate") { rot = (rot + 90f) % 360f }
            Neon("Save") { bmp?.let { b ->
                val mx = Matrix().apply { postRotate(rot) }; val r = Bitmap.createBitmap(b, 0, 0, b.width, b.height, mx, true)
                val o = Bitmap.createBitmap(r.width, r.height, Bitmap.Config.ARGB_8888)
                Canvas(o).drawBitmap(r, 0f, 0f, Paint().apply { colorFilter = ColorMatrixColorFilter(matrix(br, ct, sa)) })
                val v = ContentValues().apply { put(MediaStore.Images.Media.DISPLAY_NAME, "Ritchad_${System.currentTimeMillis()}.jpg")
                    put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg"); put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Ritchad") }
                ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)?.let { u ->
                    ctx.contentResolver.openOutputStream(u)?.use { os -> o.compress(Bitmap.CompressFormat.JPEG, 95, os) }; msg = "Saved to Pictures/Ritchad" } } }
        }
        Spacer(Modifier.height(10.dp))
        Glass(Modifier.fillMaxWidth().weight(1f)) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                bmp?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize().rotate(rot),
                    colorFilter = ColorFilter.colorMatrix(CMx(matrix(br, ct, sa).array))) } ?: Txt("Open an image, $MASTER", col = Dim) } }
        Txt("Brightness"); Slider(br, { br = it }, valueRange = -100f..100f)
        Txt("Contrast"); Slider(ct, { ct = it }, valueRange = 0.5f..2f)
        Txt("Saturation"); Slider(sa, { sa = it }, valueRange = 0f..2f)
        if (msg.isNotEmpty()) Txt(msg, col = Cyan)
    }
}

// ---------- Settings & device controls ----------
@Composable fun SettingsScreen(s: Store, back: () -> Unit, lock: () -> Unit) {
    val ctx = LocalContext.current; var sp by remember { mutableStateOf(s.speak) }; var np by remember { mutableStateOf("") }
    fun open(a: String) = ctx.startActivity(Intent(a).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    Screen("Settings", back) {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { Glass(Modifier.fillMaxWidth()) { Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f)) { Txt("Spoken replies") }; Switch(sp, { sp = it; s.speak = it }) } } }
            item { Glass(Modifier.fillMaxWidth()) { Txt("Change master PIN", true); Spacer(Modifier.height(8.dp))
                Field(np, { np = it.filter(Char::isDigit).take(8) }, "New PIN (4+ digits)", pw = true); Spacer(Modifier.height(8.dp))
                Neon("Update") { if (np.length >= 4) { s.pinHash = Store.hash(np); np = "" } } } }
            item { Glass(Modifier.fillMaxWidth()) { Txt("Device controls", true); Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Neon("Wi‑Fi") { open(Settings.ACTION_WIFI_SETTINGS) }; Neon("Bluetooth") { open(Settings.ACTION_BLUETOOTH_SETTINGS) } }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Neon("Sound") { open(Settings.ACTION_SOUND_SETTINGS) }; Neon("Display") { open(Settings.ACTION_DISPLAY_SETTINGS) } } } }
            item { Neon("🔒 Lock now", Modifier.fillMaxWidth()) { lock() } }
        }
    }
}
