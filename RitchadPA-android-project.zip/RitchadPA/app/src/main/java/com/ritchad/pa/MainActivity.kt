package com.ritchad.pa

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) { super.onCreate(b); setContent { Root() } }
}

@Composable fun Root() {
    val ctx = LocalContext.current; val s = remember { Store(ctx) }
    var unlocked by remember { mutableStateOf(false) }
    MaterialTheme(colorScheme = darkColorScheme(primary = Acc, background = Bg, surface = Bg)) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0A1630), Bg, Color.Black)))) {
            Stars()
            Box(Modifier.fillMaxSize().systemBarsPadding()) {
                if (!unlocked) Lock(s) { unlocked = true } else App(s) { unlocked = false }
            }
        }
    }
}

@Composable fun Lock(s: Store, ok: () -> Unit) {
    var pin by remember { mutableStateOf("") }; var pin2 by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }; val first = s.pinHash == null
    Column(Modifier.fillMaxSize().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        T("RITCHAD AI", 22, Color.White, FontWeight.Medium, serif = true); Orb(false, 150.dp)
        T(if (first) "Create your master PIN, $MASTER" else "Welcome back, $MASTER", 18)
        Spacer(Modifier.height(16.dp))
        Field(pin, { pin = it.filter(Char::isDigit).take(8) }, "PIN", pw = true)
        if (first) { Spacer(Modifier.height(8.dp)); Field(pin2, { pin2 = it.filter(Char::isDigit).take(8) }, "Confirm PIN", pw = true) }
        Spacer(Modifier.height(14.dp))
        Btn(if (first) "Set PIN" else "Unlock") {
            if (first) { if (pin.length >= 4 && pin == pin2) { s.pinHash = Store.hash(pin); ok() } else err = "PINs must match (4+ digits)" }
            else if (Store.hash(pin) == s.pinHash) ok() else { err = "Access denied. Only $MASTER may command me."; pin = "" }
        }
        if (err.isNotEmpty()) { Spacer(Modifier.height(8.dp)); T(err, 14, Danger) }
    }
}

@Composable fun App(s: Store, lock: () -> Unit) {
    var scr by remember { mutableStateOf("home") }; var pending by remember { mutableStateOf("") }
    val go = { k: String -> scr = k }
    BackHandler(enabled = scr != "home") { scr = "home" }
    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f)) {
            when (scr) {
                "voice" -> VoiceScreen(s, { scr = "home" }, { scr = "settings" })
                "chat" -> ChatScreen(s, pending) { pending = "" }
                "files" -> FilesScreen()
                "memory" -> MemoryScreen(s)
                "tasks" -> TasksScreen(s) { scr = "more" }
                "image" -> ImageScreen { scr = "more" }
                "settings" -> SettingsScreen(s, { scr = "more" }, lock)
                "more" -> MoreScreen(go)
                else -> HomeScreen(go) { pending = it; scr = "chat" }
            }
        }
        if (scr != "voice" && scr != "image") NavBar(if (scr == "tasks" || scr == "settings") "more" else scr, go)
    }
}

@Composable fun HomeScreen(go: (String) -> Unit, ask: (String) -> Unit) {
    var q by remember { mutableStateOf("") }
    val hr = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
    val greet = when { hr < 12 -> "Good morning,"; hr < 17 -> "Good afternoon,"; else -> "Good evening," }
    val soft = Color(0xFFD9E6FF)
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ go("more") }) { Icon(IcMenu, null, tint = Color.White) }
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                T("RITCHAD AI", 18, Color.White, FontWeight.Medium, serif = true); T("Your Personal Assistant", 11, Dim) }
            IconButton({ go("settings") }) { Icon(IcSettings, null, tint = Color.White) }
        }
        Spacer(Modifier.height(10.dp))
        T(greet, 22, soft, serif = true); T(MASTER, 28, Color.White, FontWeight.Medium, serif = true); T("Ready when you are.", 15, soft)
        Spacer(Modifier.height(4.dp))
        Box(Modifier.clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { go("voice") }) { Orb(false, 180.dp) }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(Color(0xFF2ECC71))); Spacer(Modifier.width(6.dp)); T("Online", 13, Dim) }
        Spacer(Modifier.height(12.dp))
        Panel(Modifier.fillMaxWidth()) { Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            T("\"How can I help you today?\"", 15, soft, serif = true) } }
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Field(q, { q = it }, "Ask Ritchad…", Modifier.weight(1f), onDone = { if (q.isNotBlank()) { ask(q); q = "" } })
            Spacer(Modifier.width(8.dp))
            Box(Modifier.size(54.dp).clip(RoundedCornerShape(14.dp)).background(Acc)
                .clickable { if (q.isBlank()) go("voice") else { ask(q); q = "" } }, contentAlignment = Alignment.Center) {
                Icon(if (q.isBlank()) IcMic else IcSend, null, tint = Color.White) }
        }
    }
}

@Composable fun MoreScreen(go: (String) -> Unit) {
    val rows = listOf(Triple("voice", "Voice Interaction", "Hands-free talking") to IcMic,
        Triple("tasks", "Tasks", "Today, upcoming, completed") to IcTasks,
        Triple("image", "Image Editor", "Enhance, style, crop, text") to IcImage,
        Triple("settings", "Settings", "Voice, security, devices") to IcSettings)
    Column(Modifier.fillMaxSize()) {
        TopBar("More")
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            rows.forEach { (info, ic) ->
                Panel(Modifier.fillMaxWidth(), onClick = { go(info.first) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconBox(ic); Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) { T(info.second, 16); T(info.third, 12, Dim) }
                        Icon(IcChevron, null, tint = Dim)
                    }
                }
            }
        }
    }
}
