package com.ritchad.pa

import android.graphics.*

data class Edit(val style: Int = 0, val enhance: Boolean = false, val text: String = "", val crop: Int = 0,
                val rot: Float = 0f, val br: Float = 0f, val ct: Float = 1f, val sa: Float = 1f)

val STYLES = listOf("Original", "Mono", "Sepia", "Cool", "Warm", "Neon")

private fun styleMatrix(i: Int): ColorMatrix? = when (i) {
    1 -> ColorMatrix().apply { setSaturation(0f) }
    2 -> ColorMatrix(floatArrayOf(.393f, .769f, .189f, 0f, 0f, .349f, .686f, .168f, 0f, 0f, .272f, .534f, .131f, 0f, 0f, 0f, 0f, 0f, 1f, 0f))
    3 -> ColorMatrix(floatArrayOf(.9f, 0f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 0f, 1.2f, 0f, 12f, 0f, 0f, 0f, 1f, 0f))
    4 -> ColorMatrix(floatArrayOf(1.15f, 0f, 0f, 0f, 10f, 0f, 1f, 0f, 0f, 0f, 0f, 0f, .85f, 0f, 0f, 0f, 0f, 0f, 1f, 0f))
    5 -> ColorMatrix().apply { setSaturation(1.9f) }
    else -> null
}

fun editMatrix(e: Edit): ColorMatrix {
    val en = if (e.enhance) 1.15f else 1f
    val m = ColorMatrix().apply { setSaturation(e.sa * en) }
    styleMatrix(e.style)?.let { m.postConcat(it) }
    val c = e.ct * en
    m.postConcat(ColorMatrix(floatArrayOf(c, 0f, 0f, 0f, e.br, 0f, c, 0f, 0f, e.br, 0f, 0f, c, 0f, e.br, 0f, 0f, 0f, 1f, 0f)))
    return m
}

fun render(src: Bitmap, e: Edit): Bitmap {
    var b = src
    if (e.crop == 1) { val s = minOf(b.width, b.height); b = Bitmap.createBitmap(b, (b.width - s) / 2, (b.height - s) / 2, s, s) }
    val k = when (e.crop) { 2 -> 0.75f; 3 -> 0.5f; else -> 1f }
    val mx = Matrix().apply { postRotate(e.rot); postScale(k, k) }
    b = Bitmap.createBitmap(b, 0, 0, b.width, b.height, mx, true)
    val out = Bitmap.createBitmap(b.width, b.height, Bitmap.Config.ARGB_8888)
    val cv = Canvas(out)
    cv.drawBitmap(b, 0f, 0f, Paint().apply { colorFilter = ColorMatrixColorFilter(editMatrix(e)) })
    if (e.text.isNotBlank()) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = out.width / 11f
            setShadowLayer(10f, 0f, 0f, Color.CYAN); textAlign = Paint.Align.CENTER }
        cv.drawText(e.text, out.width / 2f, out.height * 0.92f, p)
    }
    return out
}
