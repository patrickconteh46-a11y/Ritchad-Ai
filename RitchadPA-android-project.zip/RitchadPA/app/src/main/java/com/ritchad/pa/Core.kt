package com.ritchad.pa

import android.content.Context
import org.json.JSONArray
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.*

const val MASTER = "Master Patrick"

/** Persistent storage: memory, tasks, chat history, owner PIN, settings. */
class Store(c: Context) {
    private val p = c.getSharedPreferences("ritchad", 0)
    fun list(k: String): MutableList<String> {
        val a = JSONArray(p.getString(k, "[]")); return MutableList(a.length()) { a.getString(it) }
    }
    fun save(k: String, l: List<String>) { p.edit().putString(k, JSONArray(l).toString()).apply() }
    var pinHash: String?
        get() = p.getString("pin", null)
        set(v) { p.edit().putString("pin", v).apply() }
    var speak: Boolean
        get() = p.getBoolean("speak", true)
        set(v) { p.edit().putBoolean("speak", v).apply() }
    companion object {
        fun hash(s: String) = MessageDigest.getInstance("SHA-256").digest(("ritchad:$s").toByteArray())
            .joinToString("") { "%02x".format(it) }
    }
}

/** Offline assistant brain. Swap the final `else` for an LLM API call to make it smarter. */
fun brain(t: String, s: Store): String {
    val l = t.trim(); val x = l.lowercase()
    return when {
        x.startsWith("remember ") -> {
            val m = l.substring(9).removePrefix("that ").trim()
            s.save("mem", s.list("mem") + m); "Noted, $MASTER. I will remember: $m"
        }
        x.contains("what do you remember") || x == "memory" -> {
            val m = s.list("mem")
            if (m.isEmpty()) "My memory is empty, $MASTER." else "Here is what I remember, $MASTER: " + m.joinToString("; ")
        }
        x.startsWith("forget everything") -> { s.save("mem", emptyList()); "Memory cleared, $MASTER." }
        x.startsWith("add task ") -> { s.save("tasks", s.list("tasks") + "0|" + l.substring(9).trim()); "Task added, $MASTER." }
        x.contains("my tasks") || x.contains("to do") || x.contains("todo") -> {
            val t2 = s.list("tasks").filter { it.startsWith("0|") }.map { it.substring(2) }
            if (t2.isEmpty()) "No pending tasks, $MASTER." else "You have ${t2.size} pending: " + t2.joinToString(", ")
        }
        x.startsWith("what time") || x == "time" -> "It is " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date()) + ", $MASTER."
        x.contains("date") || x.contains("today") -> SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date()) + ", $MASTER."
        x.startsWith("hello") || x == "hi" || x.startsWith("hey") -> "Hello, $MASTER. How may I serve you?"
        x.contains("who are you") -> "I am Ritchad PA, your personal assistant, $MASTER. I obey only you."
        else -> "At your service, $MASTER. I can remember things, manage tasks, and tell time. Try: \"remember that ...\" or \"add task ...\"."
    }
}
