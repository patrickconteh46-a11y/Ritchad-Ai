package com.ritchad.pa

import android.content.Intent
import android.provider.OpenableColumns
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

// ---------- Chat ----------
@Composable fun ChatScreen(s: Store, pending: String, consume: () -> Unit) {
    val ctx = LocalContext.current
    val msgs = remember { mutableStateListOf<String>().apply { addAll(s.list("chat2")) } }
    var input by remember { mutableStateOf("") }; val st = rememberLazyListState()
    fun send(t: String) {
        val tm = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        msgs.add("me|$tm|$t"); msgs.add("ai|$tm|" + brain(t, s, ctx)); s.save("chat2", msgs.takeLast(80))
    }
    LaunchedEffect(pending) { if (pending.isNotBlank()) { send(pending); consume() } }
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) st.animateScrollToItem(msgs.lastIndex) }
    Column(Modifier.fillMaxSize()) {
        TopBar("Chat") { IconButton({ msgs.clear(); s.save("chat2", emptyList()) }) { Icon(IcDelete, null, tint = Dim) } }
        LazyColumn(Modifier.weight(1f).padding(horizontal = 16.dp), state = st, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(msgs.size) { i ->
                val p = msgs[i].split("|", limit = 3); val me = p[0] == "me"
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (me) Arrangement.End else Arrangement.Start, verticalAlignment = Alignment.Top) {
                    if (!me) { Box(Modifier.size(32.dp).clip(CircleShape).background(Acc), contentAlignment = Alignment.Center) {
                        T("R", 15, Color.White, FontWeight.Bold, serif = true) }; Spacer(Modifier.width(8.dp)) }
                    Box(Modifier.widthIn(max = 280.dp).clip(RoundedCornerShape(16.dp)).background(if (me) Color(0xFF123B6B) else CardBg)
                        .border(1.dp, Line, RoundedCornerShape(16.dp)).padding(12.dp)) {
                        Column { T(p[2]); Spacer(Modifier.height(4.dp)); T(p[1], 11, Dim, m = Modifier.align(Alignment.End)) } }
                }
            }
        }
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Field(input, { input = it }, "Type a message…", Modifier.weight(1f), onDone = { if (input.isNotBlank()) { send(input); input = "" } })
            Spacer(Modifier.width(8.dp))
            Box(Modifier.size(54.dp).clip(RoundedCornerShape(14.dp)).background(Acc)
                .clickable { if (input.isNotBlank()) { send(input); input = "" } }, contentAlignment = Alignment.Center) {
                Icon(IcSend, null, tint = Color.White) }
        }
    }
}

// ---------- Tasks ----------
@Composable fun TasksScreen(s: Store, back: () -> Unit) {
    val l = remember { mutableStateListOf<String>().apply { addAll(s.list("tasks")) } }
    var tab by remember { mutableStateOf("Today") }; var dlg by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        TopBar("Tasks", back)
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Today", "Upcoming", "Completed").forEach { Chip(it, tab == it) { tab = it } } }
        val shown = l.indices.filter {
            val (d, w, _) = parseTask(l[it])
            when (tab) { "Completed" -> d; "Today" -> !d && w == "T"; else -> !d && w == "U" } }
        LazyColumn(Modifier.weight(1f).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(shown.size) { n ->
                val i = shown[n]; val (d, w, txt) = parseTask(l[i])
                Panel(Modifier.fillMaxWidth()) { Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(24.dp).clip(CircleShape).border(2.dp, if (d) Acc else Dim, CircleShape)
                        .background(if (d) Acc else Color.Transparent)
                        .clickable { l[i] = "${if (d) 0 else 1}|$w|$txt"; s.save("tasks", l) }, contentAlignment = Alignment.Center) {
                        if (d) Icon(IcCheck, null, tint = Color.White, modifier = Modifier.size(16.dp)) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) { T(txt, 15, if (d) Dim else Color.White); T(if (w == "T") "Today" else "Upcoming", 12, Dim) }
                    IconButton({ l.removeAt(i); s.save("tasks", l) }) { Icon(IcDelete, null, tint = Dim) } } }
            }
        }
        Btn("Add Task", Modifier.fillMaxWidth().padding(16.dp), IcAdd) { dlg = true }
    }
    if (dlg) {
        var txt by remember { mutableStateOf("") }; var w by remember { mutableStateOf("T") }
        AlertDialog(onDismissRequest = { dlg = false }, containerColor = CardBg,
            confirmButton = { TextButton({ if (txt.isNotBlank()) { l.add("0|$w|${txt.trim()}"); s.save("tasks", l); dlg = false } }) { Text("Add", color = Acc) } },
            dismissButton = { TextButton({ dlg = false }) { Text("Cancel", color = Dim) } },
            title = { T("New task", 18) },
            text = { Column { Field(txt, { txt = it }, "What needs doing?"); Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Chip("Today", w == "T") { w = "T" }; Chip("Upcoming", w == "U") { w = "U" } } } })
    }
}

// ---------- Memory ----------
@Composable fun MemoryScreen(s: Store) {
    val l = remember { mutableStateListOf<String>().apply { addAll(s.list("mem")) } }
    val tabs = listOf("P" to "Personal", "F" to "Preferences", "I" to "Important")
    var tab by remember { mutableStateOf("P") }; var dlg by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        TopBar("Memory")
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            tabs.forEach { Chip(it.second, tab == it.first) { tab = it.first } } }
        val shown = l.indices.filter { parseMem(l[it]).first == tab }
        LazyColumn(Modifier.weight(1f).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(shown.size) { n ->
                val i = shown[n]; val (c, title, body) = parseMem(l[i])
                Panel(Modifier.fillMaxWidth()) { Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBox(when (c) { "F" -> IcHeart; "I" -> IcStar; else -> IcPerson }, if (c == "I") Color(0xFFFFC83D) else Cyan)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) { T(title, 15); T(body, 13, Dim) }
                    IconButton({ l.removeAt(i); s.save("mem", l) }) { Icon(IcDelete, null, tint = Dim) } } }
            }
        }
        Btn("Add Memory", Modifier.fillMaxWidth().padding(16.dp), IcAdd) { dlg = true }
    }
    if (dlg) {
        var ti by remember { mutableStateOf("") }; var bo by remember { mutableStateOf("") }; var c by remember { mutableStateOf(tab) }
        AlertDialog(onDismissRequest = { dlg = false }, containerColor = CardBg,
            confirmButton = { TextButton({ if (bo.isNotBlank()) { l.add("$c|${ti.ifBlank { "Note" }.replace("|", " ")}|${bo.trim()}"); s.save("mem", l); dlg = false } }) { Text("Save", color = Acc) } },
            dismissButton = { TextButton({ dlg = false }) { Text("Cancel", color = Dim) } },
            title = { T("New memory", 18) },
            text = { Column { Field(ti, { ti = it }, "Title"); Spacer(Modifier.height(8.dp)); Field(bo, { bo = it }, "Details"); Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { tabs.forEach { Chip(it.second.take(8), c == it.first) { c = it.first } } } } })
    }
}

// ---------- Files ----------
@Composable fun FilesScreen() {
    val ctx = LocalContext.current; val dir = remember { File(ctx.filesDir, "uploads").apply { mkdirs() } }
    var files by remember { mutableStateOf(dir.listFiles()?.toList() ?: emptyList()) }
    var q by remember { mutableStateOf("") }; var tab by remember { mutableStateOf("All") }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { u ->
            val name = ctx.contentResolver.query(u, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null } ?: "file_${System.currentTimeMillis()}"
            ctx.contentResolver.openInputStream(u)?.use { i -> File(dir, name).outputStream().use { o -> i.copyTo(o) } }
        }
        files = dir.listFiles()?.toList() ?: emptyList()
    }
    fun kind(f: File) = when (f.extension.lowercase()) {
        "pdf", "doc", "docx", "txt", "xls", "xlsx", "ppt", "pptx" -> "Documents"
        "jpg", "jpeg", "png", "gif", "webp" -> "Images"; else -> "Other" }
    Column(Modifier.fillMaxSize()) {
        TopBar("Files")
        Column(Modifier.padding(horizontal = 16.dp)) {
            Field(q, { q = it }, "Search files…", Modifier.fillMaxWidth()); Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("All", "Documents", "Images", "Other").forEach { Chip(it, tab == it) { tab = it } } }
        }
        val shown = files.filter { it.name.contains(q, true) && (tab == "All" || kind(it) == tab) }
        if (shown.isEmpty()) Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { T("No files yet, $MASTER.", 14, Dim) }
        else LazyColumn(Modifier.weight(1f).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(shown.size) { n ->
                val f = shown[n]; val ext = f.extension.lowercase()
                Panel(Modifier.fillMaxWidth()) { Row(verticalAlignment = Alignment.CenterVertically) {
                    when (kind(f)) {
                        "Images" -> IconBox(IcImage, Color(0xFF16C7B8))
                        else -> Box(Modifier.size(44.dp).clip(RoundedCornerShape(12.dp))
                            .background(if (ext == "pdf") Color(0xFFE53935) else if (kind(f) == "Documents") Color(0xFF2B6FE0) else Color(0xFF3A4A66)),
                            contentAlignment = Alignment.Center) { T(if (ext.isEmpty()) "FILE" else ext.take(4).uppercase(), 11, Color.White, FontWeight.Bold) }
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) { T(f.name, 15); T("${f.length() / 1024} KB • " + SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date(f.lastModified())), 12, Dim) }
                    IconButton({ f.delete(); files = dir.listFiles()?.toList() ?: emptyList() }) { Icon(IcDelete, null, tint = Dim) } } }
            }
        }
        Btn("Upload File", Modifier.fillMaxWidth().padding(16.dp), IcAdd) { pick.launch(arrayOf("*/*")) }
    }
}

// ---------- Settings ----------
@Composable fun SettingsScreen(s: Store, back: () -> Unit, lock: () -> Unit) {
    val ctx = LocalContext.current; var sp by remember { mutableStateOf(s.speak) }; var np by remember { mutableStateOf("") }
    var open by remember { mutableStateOf("") }
    fun launch(a: String) = ctx.startActivity(Intent(a).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    @Composable fun Row2(k: String, ic: androidx.compose.ui.graphics.vector.ImageVector, title: String, sub: String, body: @Composable ColumnScope.() -> Unit) {
        Panel(Modifier.fillMaxWidth(), onClick = { open = if (open == k) "" else k }) {
            Row(verticalAlignment = Alignment.CenterVertically) { IconBox(ic); Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) { T(title, 16); T(sub, 12, Dim) }; Icon(IcChevron, null, tint = Dim) }
        }
        if (open == k) Panel(Modifier.fillMaxWidth(), c = body)
    }
    Column(Modifier.fillMaxSize()) {
        TopBar("Settings", back)
        LazyColumn(Modifier.weight(1f).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { Panel(Modifier.fillMaxWidth()) { Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(52.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Acc, Cyan))), contentAlignment = Alignment.Center) { T("P", 22, Color.White, FontWeight.Bold, serif = true) }
                Spacer(Modifier.width(14.dp)); Column { T(MASTER, 17); T("Owner & Creator", 12, Dim) } } } }
            item { Row2("voice", IcMic, "Voice & Speech", "Spoken replies, hands-free") {
                Row(verticalAlignment = Alignment.CenterVertically) { T("Spoken replies", 15, m = Modifier.weight(1f)); Switch(sp, { sp = it; s.speak = it }) } } }
            item { Row2("ai", IcTune, "AI Model", "Offline assistant") { T("Ritchad currently runs offline on built-in commands. A cloud AI brain can be connected later.", 13, Dim) } }
            item { Row2("sec", IcSecurity, "Privacy & Security", "Master PIN, lock") {
                Field(np, { np = it.filter(Char::isDigit).take(8) }, "New PIN (4+ digits)", pw = true); Spacer(Modifier.height(8.dp))
                Btn("Update PIN") { if (np.length >= 4) { s.pinHash = Store.hash(np); np = "" } } } }
            item { Row2("dev", IcDevices, "Connected Devices", "Wi‑Fi, Bluetooth, sound, display") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Chip("Wi‑Fi", false) { launch(Settings.ACTION_WIFI_SETTINGS) }; Chip("Bluetooth", false) { launch(Settings.ACTION_BLUETOOTH_SETTINGS) } }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Chip("Sound", false) { launch(Settings.ACTION_SOUND_SETTINGS) }; Chip("Display", false) { launch(Settings.ACTION_DISPLAY_SETTINGS) } } } }
            item { Row2("about", IcInfo, "About", "Version 2.0") { T("Ritchad AI — built for $MASTER.", 13, Dim) } }
            item { Box(Modifier.fillMaxWidth().height(50.dp).clip(RoundedCornerShape(14.dp)).border(1.dp, Danger, RoundedCornerShape(14.dp)).clickable { lock() },
                contentAlignment = Alignment.Center) { T("Sign Out", 15, Danger) } }
            item { Spacer(Modifier.height(12.dp)) }
        }
    }
}
