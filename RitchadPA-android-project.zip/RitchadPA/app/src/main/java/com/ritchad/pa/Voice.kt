package com.ritchad.pa

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.WindowManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import java.util.Locale

@Composable fun VoiceScreen(s: Store, back: () -> Unit, openSettings: () -> Unit) {
    val ctx = LocalContext.current; val h = remember { Handler(Looper.getMainLooper()) }
    var status by remember { mutableStateOf("Speak any time, $MASTER") }
    var listening by remember { mutableStateOf(false) }; var reply by remember { mutableStateOf("") }
    var hands by remember { mutableStateOf(true) }
    val resumed = remember { booleanArrayOf(true) }
    val go = remember { arrayOfNulls<() -> Unit>(1) }; val done = remember { arrayOfNulls<() -> Unit>(1) }
    val tts = remember { var t: TextToSpeech? = null
        t = TextToSpeech(ctx) { t?.language = Locale.getDefault()
            t?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onDone(id: String?) { h.post { done[0]?.invoke() } }
                @Deprecated("x") override fun onError(id: String?) { h.post { done[0]?.invoke() } } }) }
        t!! }
    val rec = remember { SpeechRecognizer.createSpeechRecognizer(ctx) }
    fun again(d: Long) { if (hands && resumed[0]) h.postDelayed({ if (hands && resumed[0]) go[0]?.invoke() }, d) }
    done[0] = { again(300) }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it) again(100) else { hands = false; status = "Microphone permission denied" } }
    go[0] = {
        if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) perm.launch(Manifest.permission.RECORD_AUDIO)
        else {
            rec.setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle?) {
                    listening = false
                    val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (t == null) { again(300); return }
                    status = "You: $t"; val x = t.lowercase()
                    if (x.contains("stop listening") || x == "stop") { hands = false; status = "Paused. Tap the mic to resume."; return }
                    val a = brain(t, s, ctx); reply = a
                    if (s.speak) tts.speak(a, TextToSpeech.QUEUE_FLUSH, null, "r") else again(400)
                }
                override fun onError(e: Int) {
                    listening = false
                    when (e) {
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> again(300)
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> { rec.cancel(); again(800) }
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> { hands = false; status = "Microphone permission needed" }
                        else -> { status = "Voice hiccup, retrying…"; again(1500) }
                    }
                }
                override fun onReadyForSpeech(p: Bundle?) {}; override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}; override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}; override fun onPartialResults(b: Bundle?) {}
                override fun onEvent(t: Int, b: Bundle?) {}
            })
            listening = true
            rec.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM))
        }
    }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val o = LifecycleEventObserver { _, e -> when (e) {
            Lifecycle.Event.ON_PAUSE -> { resumed[0] = false; rec.cancel(); listening = false }
            Lifecycle.Event.ON_RESUME -> { resumed[0] = true; again(700) }
            else -> {} } }
        owner.lifecycle.addObserver(o); onDispose { owner.lifecycle.removeObserver(o) } }
    DisposableEffect(Unit) {
        val w = (ctx as Activity).window; w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose { resumed[0] = false; h.removeCallbacksAndMessages(null); w.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            tts.shutdown(); rec.destroy() } }
    fun pause() { hands = false; rec.cancel(); tts.stop(); listening = false; status = "Paused. Tap the mic to resume." }
    fun resume() { hands = true; status = "Speak any time, $MASTER"; again(0) }

    Column(Modifier.fillMaxSize()) {
        TopBar("Voice Interaction", { hands = false; back() }) { IconButton(openSettings) { Icon(IcSettings, null, tint = Color.White) } }
        Column(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 20.dp), horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center) {
            Orb(listening, 220.dp)
            Spacer(Modifier.height(6.dp)); T(if (listening) "Listening…" else "Ritchad", 24, Color.White)
            Spacer(Modifier.height(10.dp)); Wave(listening)
            Spacer(Modifier.height(8.dp)); T(if (listening) "Speak now, I'm listening." else status, 14, Dim)
            if (reply.isNotEmpty()) { Spacer(Modifier.height(14.dp)); Panel(Modifier.fillMaxWidth()) { T(reply) } }
        }
        Row(Modifier.fillMaxWidth().padding(bottom = 24.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(52.dp).clip(CircleShape).background(CardBg).border(1.dp, Line, CircleShape).clickable { pause() }, contentAlignment = Alignment.Center) {
                Icon(IcClose, null, tint = Color.White) }
            Box(Modifier.size(78.dp).clip(CircleShape).background(Acc).clickable { if (hands) pause() else resume() }, contentAlignment = Alignment.Center) {
                Icon(IcMic, null, tint = Color.White, modifier = Modifier.size(36.dp)) }
            Box(Modifier.size(52.dp).clip(CircleShape).background(CardBg).border(1.dp, Line, CircleShape).clickable { openSettings() }, contentAlignment = Alignment.Center) {
                Icon(IcSettings, null, tint = Color.White) }
        }
    }
}
