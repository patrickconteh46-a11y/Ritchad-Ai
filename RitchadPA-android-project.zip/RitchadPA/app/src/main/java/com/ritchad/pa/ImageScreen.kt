package com.ritchad.pa

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

@Composable fun OptRow(icon: ImageVector, label: String, tag: String = "", on: () -> Unit) =
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(CardBg).clickable { on() }.padding(14.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Cyan, modifier = Modifier.size(22.dp)); Spacer(Modifier.width(14.dp))
        T(label, 15, Color.White, m = Modifier.weight(1f))
        if (tag.isNotEmpty()) { T(tag, 12, Acc); Spacer(Modifier.width(6.dp)) }
        Icon(IcChevron, null, tint = Dim)
    }

@Composable fun ImageScreen(back: () -> Unit) {
    val ctx = LocalContext.current
    var bmp by remember { mutableStateOf<Bitmap?>(null) }; var ed by remember { mutableStateOf(Edit()) }
    var open by remember { mutableStateOf("") }; var msg by remember { mutableStateOf("") }
    val prev = remember(bmp, ed) { bmp?.let { render(it, ed) } }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u: Uri? ->
        if (u != null) {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
            val sample = maxOf(1, maxOf(o.outWidth, o.outHeight) / 1280)
            ctx.contentResolver.openInputStream(u)?.use {
                bmp = BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample }) }
            ed = Edit(); msg = ""
        }
    }
    fun tog(k: String) { open = if (open == k) "" else k }
    Column(Modifier.fillMaxSize()) {
        TopBar("Image Editor", back)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Panel(Modifier.fillMaxWidth().height(230.dp), onClick = { pick.launch("image/*") }) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    if (prev != null) Image(prev.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                    else T("Tap to open an image, $MASTER", 14, Dim) } }
            T("Edit Options", 15, Color.White, m = Modifier.padding(top = 6.dp))
            OptRow(IcMagic, "Remove background", "Soon") { msg = "Background removal needs cloud AI. Planned for a later version." }
            OptRow(IcMagic, "Enhance quality", if (ed.enhance) "On" else "Off") { ed = ed.copy(enhance = !ed.enhance) }
            OptRow(IcPalette, "Change style", STYLES[ed.style]) { tog("style") }
            if (open == "style") Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                STYLES.forEachIndexed { i, n -> Chip(n, ed.style == i) { ed = ed.copy(style = i) } } }
            OptRow(IcText, "Add text", if (ed.text.isBlank()) "" else "Added") { tog("text") }
            if (open == "text") Field(ed.text, { ed = ed.copy(text = it) }, "Type text for the image", Modifier.fillMaxWidth())
            OptRow(IcCrop, "Crop / Resize", listOf("Original", "Square", "75%", "50%")[ed.crop]) { tog("crop") }
            if (open == "crop") Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Original", "Square", "75%", "50%").forEachIndexed { i, n -> Chip(n, ed.crop == i) { ed = ed.copy(crop = i) } } }
            OptRow(IcRefresh, "Rotate 90°") { ed = ed.copy(rot = (ed.rot + 90f) % 360f) }
            OptRow(IcTune, "Adjust light & color") { tog("adj") }
            if (open == "adj") Panel(Modifier.fillMaxWidth()) {
                T("Brightness", 13, Dim); Slider(ed.br, { ed = ed.copy(br = it) }, valueRange = -80f..80f)
                T("Contrast", 13, Dim); Slider(ed.ct, { ed = ed.copy(ct = it) }, valueRange = 0.6f..1.6f)
                T("Saturation", 13, Dim); Slider(ed.sa, { ed = ed.copy(sa = it) }, valueRange = 0f..2f) }
            if (msg.isNotEmpty()) T(msg, 13, Cyan)
            Spacer(Modifier.height(4.dp))
        }
        Btn("Apply Changes", Modifier.fillMaxWidth().padding(16.dp)) {
            val o = prev
            if (o == null) msg = "Open an image first, $MASTER."
            else {
                val v = ContentValues().apply { put(MediaStore.Images.Media.DISPLAY_NAME, "Ritchad_${System.currentTimeMillis()}.jpg")
                    put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg"); put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Ritchad") }
                val u = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)
                if (u != null) { ctx.contentResolver.openOutputStream(u)?.use { os -> o.compress(Bitmap.CompressFormat.JPEG, 95, os) }; msg = "Saved to Pictures/Ritchad" }
                else msg = "Couldn't save the image."
            }
        }
    }
}
