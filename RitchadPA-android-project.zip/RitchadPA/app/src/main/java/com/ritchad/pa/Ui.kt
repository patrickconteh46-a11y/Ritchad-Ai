package com.ritchad.pa

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Bg = Color(0xFF050B1A); val CardBg = Color(0xFF0C1830); val Line = Color(0xFF173360)
val Acc = Color(0xFF1FA2FF); val Cyan = Color(0xFF00E5FF); val Dim = Color(0xFF8CA3C4); val Danger = Color(0xFFFF4D5E)

val IcHome = Icons.Filled.Home; val IcChat = Icons.Filled.Chat; val IcFolder = Icons.Filled.Folder
val IcBrain = Icons.Filled.Psychology; val IcMenu = Icons.Filled.Menu; val IcMic = Icons.Filled.Mic
val IcSettings = Icons.Filled.Settings; val IcSend = Icons.Filled.Send; val IcAdd = Icons.Filled.Add
val IcClose = Icons.Filled.Close; val IcSearch = Icons.Filled.Search; val IcBack = Icons.Filled.ArrowBack
val IcDelete = Icons.Filled.Delete; val IcSecurity = Icons.Filled.Security; val IcDevices = Icons.Filled.Devices
val IcInfo = Icons.Filled.Info; val IcTune = Icons.Filled.Tune; val IcCrop = Icons.Filled.Crop
val IcPalette = Icons.Filled.Palette; val IcText = Icons.Filled.TextFields; val IcMagic = Icons.Filled.AutoFixHigh
val IcRefresh = Icons.Filled.Refresh; val IcImage = Icons.Filled.Image; val IcDoc = Icons.Filled.Description
val IcCheck = Icons.Filled.Check; val IcChevron = Icons.Filled.ChevronRight; val IcPerson = Icons.Filled.Person
val IcHeart = Icons.Filled.Favorite; val IcStar = Icons.Filled.Star; val IcTasks = Icons.Filled.Check

@Composable fun Stars() = Canvas(Modifier.fillMaxSize()) {
    val rnd = java.util.Random(7)
    repeat(70) { drawCircle(Cyan.copy(alpha = 0.06f + rnd.nextFloat() * 0.3f), rnd.nextFloat() * 2f + 0.5f,
        Offset(rnd.nextFloat() * size.width, rnd.nextFloat() * size.height)) }
    val c1 = Offset(size.width * .5f, size.height * .25f)
    drawCircle(Brush.radialGradient(listOf(Acc.copy(.25f), Color.Transparent), c1, size.width * .8f), size.width * .8f, c1)
}

@Composable fun T(t: String, size: Int = 15, col: Color = Color.White, w: FontWeight = FontWeight.Normal,
                  m: Modifier = Modifier, serif: Boolean = false) =
    Text(t, modifier = m, color = col, fontSize = size.sp, fontWeight = w,
        fontFamily = if (serif) FontFamily.Serif else FontFamily.Default)

@Composable fun Panel(m: Modifier = Modifier, r: Int = 16, onClick: (() -> Unit)? = null, c: @Composable ColumnScope.() -> Unit) {
    val sh = RoundedCornerShape(r.dp)
    var mod = m.clip(sh).background(CardBg.copy(alpha = .9f)).border(1.dp, Line, sh)
    if (onClick != null) mod = mod.clickable { onClick() }
    Column(mod.padding(14.dp), content = c)
}

@Composable fun Btn(t: String, m: Modifier = Modifier.fillMaxWidth(), icon: ImageVector? = null, on: () -> Unit) =
    Row(m.height(50.dp).clip(RoundedCornerShape(14.dp))
        .background(Brush.horizontalGradient(listOf(Color(0xFF1B8FFF), Color(0xFF35C2FF)))).clickable { on() },
        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
        if (icon != null) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)) }
        T(t, 15, Color.White, FontWeight.Medium)
    }

@Composable fun Chip(t: String, sel: Boolean, on: () -> Unit) {
    val sh = RoundedCornerShape(20.dp)
    Box(Modifier.clip(sh).background(if (sel) Acc else CardBg).border(1.dp, if (sel) Acc else Line, sh)
        .clickable { on() }.padding(horizontal = 16.dp, vertical = 7.dp)) { T(t, 13, if (sel) Color.White else Dim) }
}

@Composable fun Field(v: String, ch: (String) -> Unit, hint: String, m: Modifier = Modifier, pw: Boolean = false, onDone: (() -> Unit)? = null) =
    OutlinedTextField(v, ch, m, placeholder = { Text(hint, color = Dim) }, singleLine = true,
        shape = RoundedCornerShape(14.dp),
        visualTransformation = if (pw) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(imeAction = if (onDone != null) ImeAction.Send else ImeAction.Default),
        keyboardActions = KeyboardActions(onSend = { onDone?.invoke() }),
        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Acc, unfocusedBorderColor = Line,
            focusedContainerColor = CardBg, unfocusedContainerColor = CardBg,
            focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = Cyan))

@Composable fun TopBar(title: String, back: (() -> Unit)? = null, right: @Composable () -> Unit = {}) =
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        if (back != null) IconButton(back) { Icon(IcBack, null, tint = Color.White) } else Spacer(Modifier.width(16.dp))
        T(title, 20, Color.White, FontWeight.Medium, Modifier.weight(1f)); right()
    }

@Composable fun IconBox(icon: ImageVector, tint: Color = Cyan) =
    Box(Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF10264A)), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(24.dp)) }

@Composable fun NavBar(cur: String, go: (String) -> Unit) {
    val items = listOf(Triple("home", "Home", IcHome), Triple("chat", "Chat", IcChat), Triple("files", "Files", IcFolder),
        Triple("memory", "Memory", IcBrain), Triple("more", "More", IcMenu))
    Row(Modifier.fillMaxWidth().background(Color(0xFF060F22)).padding(vertical = 8.dp)) {
        items.forEach { (k, l, ic) ->
            val sel = cur == k
            Column(Modifier.weight(1f).clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { go(k) },
                horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(ic, null, tint = if (sel) Acc else Dim, modifier = Modifier.size(24.dp))
                T(l, 11, if (sel) Acc else Dim)
            }
        }
    }
}

@Composable fun Orb(active: Boolean, d: Dp = 200.dp, letter: String = "R") {
    val t = rememberInfiniteTransition(label = "o")
    val sc by t.animateFloat(1f, if (active) 1.08f else 1.03f,
        infiniteRepeatable(tween(if (active) 700 else 2400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "s")
    val rot by t.animateFloat(0f, 360f, infiniteRepeatable(tween(if (active) 2500 else 9000, easing = LinearEasing)), label = "r")
    Box(Modifier.size(d * 1.4f), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(d * 1.4f).scale(sc)) {
            val c = center; val r = d.toPx() / 2
            drawCircle(Brush.radialGradient(listOf(Cyan.copy(.35f), Acc.copy(.12f), Color.Transparent), c, r * 1.4f), r * 1.4f, c)
            drawCircle(Brush.radialGradient(listOf(Color(0xFF0B1F44), Color(0xFF040A18)), c, r), r * .82f, c)
            drawCircle(Cyan.copy(.9f), r * .82f, c, style = Stroke(3f))
            drawCircle(Acc.copy(.5f), r * .95f, c, style = Stroke(1.5f))
            drawCircle(Acc.copy(.3f), r * 1.1f, c, style = Stroke(1f))
            rotate(rot, c) { drawArc(Cyan, 0f, 70f, false, Offset(c.x - r * .95f, c.y - r * .95f), Size(r * 1.9f, r * 1.9f),
                style = Stroke(6f, cap = StrokeCap.Round)) }
        }
        T(letter, (d.value * 0.36f).toInt(), Color.White, FontWeight.Medium, serif = true)
    }
}

@Composable fun Wave(active: Boolean, m: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "w")
    val ph by t.animateFloat(0f, 6.2832f, infiniteRepeatable(tween(900, easing = LinearEasing)), label = "p")
    Canvas(m.fillMaxWidth().height(70.dp)) {
        val n = 41; val gap = size.width / n
        for (i in 0 until n) {
            val env = 1f - kotlin.math.abs(i - n / 2f) / (n / 2f)
            val a = if (active) 0.3f + 0.7f * kotlin.math.abs(kotlin.math.sin(ph + i * 0.5f)) else 0.1f
            val h = size.height * env * a
            drawLine(Cyan, Offset(gap * i + gap / 2, (size.height - h) / 2), Offset(gap * i + gap / 2, (size.height + h) / 2),
                strokeWidth = gap * 0.5f, cap = StrokeCap.Round)
        }
    }
}
